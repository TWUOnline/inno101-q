---
Topic: 
tags: 
---

> [!faq] Questions
> What questions do you have about the topic?
> - bullets?
> - Yes


> [!note] Notes
> Imagine you would write about this topic and each of the questions above in a paper. How would you do it? It is probably just one or two sentences for each question. It is the most intense condensation of the information on this topic and forces you to be on point. 
> 
> You can have multiple alternatives. 


> [!tldr] Summary
> A short summary - or an abstract in 3 sentences, relating to YOU. What did YOU find interesting about this topic. 


> [!info] Related
> Wikilinks to related topics and articles.
