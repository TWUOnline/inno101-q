This tool is designed to support your learning in each unit. It helps you:

- Stay on track to meet your learning goals.
- Assess your understanding of the unit outcomes.
- Reflect on insights and questions you have about the unit

## Goals

> [!tldr] Define clear and specific goals to focus your efforts during the unit.
>
>**Checklist for Setting Goals:**
>- What do you want to achieve by the end of the unit?
>- Are your goals measurable and realistic?
>- How will you know if you’ve succeeded?

**What were your learning goals for this unit?**
- Describe each goal in your own words.

## Self-Assessment of Learning Outcomes

>[!tldr] Describe your understanding of the unit learning outcomes.
>1. Build and customize technology-integrated workflows to enhance and enrich your learning journey;
>2. Apply digital literacy skills to evaluate the legitimacy, credibility and reliability of online resources for academic study;
>3. Practice evaluative judgment to document your process of learning in complex domains of knowledge; 
>4. Create a personalized narrative to document and express your learning process;
>5. Evaluate digital tools, platforms, and interactions based on ethical principles;
>6. Develop personal and professional learning networks to discover and share knowledge, collaborate with others, and become engaged digital global citizens;
>7. Create inclusive digital communities which embody a sense of belonging, connection, and Christian hospitality.

Self-evaluation helps identify strengths and areas for improvement.

**Checklist for Self-Evaluation:**

- Can you demonstrate your understanding of the unit outcomes?
- What areas need more focus to reach proficiency?

LO1: Describe your engagement with digital technology.  What technology-integrated workflow do you use?  What other digital tools do you use?
```
Write here
```
LO2: How have you applied digital tools to support learning in an academic environment?
```
Write here
```
LO3: Explain what digital literacy means to you.
```
Write here
```
LO4: What are some privacy concerns related to digital platforms and tools?  How can you address these concerns?
```
Write here
```
LO5: Describe how you can protect yourself and others in the digital environment.
```
Write here
```
LO6: Identify your goals for developing digital literacies.
```
Write here
```

## Unit Wow & Wonder

>[!tldr] Self-evaluation helps identify strengths and areas for improvement.
>
>**Checklist for Self-Evaluation:**
>
>- Can you demonstrate your understanding of the unit outcomes?
>- What learning activities were most helpful?
>- What areas need more focus to reach proficiency?

Take 5 minutes to reflect on what you learned in the unit.

1. WOW: What surprised you?  What were you excited to learn about?
2. WONDER: What are you curious about?  What questions do you have?

```
Write here
```

## Goals Assessment

>[!tldr] Reviewing your goals helps you refine your approach for the next unit.
>**Checklist for Goals Assessment:**
>
>- Which goals were fully achieved?
>- Which goals were partially achieved, and why?
>- What will you do differently in the next unit?

**Assess your progress.**
- Categorize each goal as fully, partially, or not achieved.

<br> <label> <input type="radio" name="option" value=" Did not achieve"> Did not achieve </label> <br> <label> <input type="radio" name="option" value="Achieved partially"> Achieved partially </label> <br> <label> <input type="radio" name="option" value="Achieved completely"> Achieved completely </label>

| Goals | Rating |
| ----- | ------ |
|       |        |
|       |        |
|       |        |


### Well done!

You can choose to export all your submitted text and save your document on your computer.  Feel free to submit to your instructor for feedback.